"""Hospital Appointment & Follow-up Agent entry point."""

if __name__ == "__main__":
    print("Hospital Agent project initialized.")
