# Hospital Appointment & Follow-up Agent

An Agentic AI project for hospital appointment management and patient follow-up workflows.

## Planned capabilities

- Doctor search
- Appointment availability
- Appointment booking
- Cancellation and rescheduling
- Hospital information using RAG
- Follow-up tracking
- Reminder notifications
- Human confirmation before important actions

## Architecture

Streamlit UI → FastAPI → LangGraph Agent → Tools → MySQL / ChromaDB

## Important scope

This project is an administrative healthcare assistant. It is not intended to diagnose diseases, prescribe medication, or replace medical professionals.

## Development order

1. Project setup
2. MySQL database
3. Doctor/patient/appointment CRUD
4. Appointment workflow
5. LLM integration
6. Tool calling
7. LangGraph agent
8. RAG
9. Follow-up workflow
10. Human-in-the-loop
11. Streamlit UI
12. FastAPI
13. Testing and evaluation
14. Deployment
