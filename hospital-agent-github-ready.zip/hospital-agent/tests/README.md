# Tests

Automated tests for the hospital agent will be added as each feature is implemented.
